#include "custom_pod.h"

NSString* sayHi() {
    return @"Hi"
}