#import <Foundation/Foundation.h>

NSString* sayHi();